package de.unistuttgart.vis.dsass2019.ex01.p3;


public class Queue<T> implements IQueue<T>  {

	private Node font = null;
	private Node back = null;
	private int counter = 0;
	
	private class Node{
		T t;
		Node next;
	}
	 
	@Override
	public void enqueue(T t)  {
		// TODO Auto-generated method stub
		Node oldBack = back;
	    back = new Node();
	    back.t = t;
	    if(isEmpty()){
	      font = back;
	    }else{
	      oldBack.next = back;
	    }
	    counter++;
	}

	@Override
	public T dequeue()  {
		// TODO Auto-generated method stub
		if(isEmpty()){
		      return null; 
		}
		T t = font.t;
		if(font == back){
			back = back.next;
		}
		font = font.next;
		return t;
	}

	@Override
	public T front()   {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return font == null;
	}
	

}
