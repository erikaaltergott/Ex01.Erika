package de.unistuttgart.vis.dsass2019.ex01.p3;


public class Stack<T> implements IStack<T> {

	private int counter = 0;
	private Node top = null;
	
	private class Node{
        private Node next = null;
        private T t = null;

        private Node(T t1) {
            this.t = t1;
        }
	}
	
	@Override
	public void push(T t){
		// TODO Auto-generated method stub
		Node node = new Node(t);
		if (top == null) {
			top = node;
		} else {
		    node.next = top;
		    top = node;
		}
		counter++;
	}

	@Override
	public T pop() {
		// TODO Auto-generated method stub
		T t = null;

        if (top != null) {
            t = top.t;
            top = top.next;
            counter--;
        }

        return t;
	}

	@Override
	public T top(){
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return counter == 0;
	}
	

}
