package de.unistuttgart.vis.dsass2019.ex01.p2;

public class SpeedList<T> implements ISpeedList<T> {
	
	private int counter = 0;
	
	class Node {
		
		private T t;
		private Node next;
		
		public  Node(T t1, Node next1) {
		t=t1;
		next=next1;
		}
		
		public Node() {
			t=null;
			next=null;
		}
		
		public void setElement(T t1) {
			t = t1;
			 
		}
		 
		public T getElement() {
			return t;
		}
		 
		public void setNext(Node next1) {
			next = next1;
		}
		 
		public Node getNext() {
			return next;
		}
			
	}
	
	private Node head;
	
	public SpeedList() {
		head = new Node();
	}
	
	@Override
	public int size() {
		return counter;
		
	}

	@Override
	public void prepend(T t) {
		// TODO Auto-generated method stub
		Node next1 = new Node(t, head.getNext());
		head.setNext(next1);
		counter++;
	}

	@Override
	public T getElementAt(int pos) {
		// TODO Auto-generated method stub
		Node next1 = new Node(null, head.getNext());
		while (pos>counter) {
			next1.getNext();
		}
		return next1.getElement();
	}

	@Override
	public T getNext8thElementOf(int pos) {
		// TODO Auto-generated method stub
		return getElementAt(pos+8);
	}
}
